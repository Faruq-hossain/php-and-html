Please Read this :-

to start the project you have to go to applicationlayer (FOLDER) and open the Doctorpatient.php


There is an expected error in the patient and doctor login but once you login this error will vanish


The project database structure is in the datalayer (FOLDER) - SQL DATABASE EXPORT 
and its called registration(1)
